--Retrieve Phone Type List (for both Client and Business, no data return, this could be used for new phone type definition)


SELECT * from OCBS.OCBSCATL  where element = 'CATEGORY_TELEPHONE';

	

select OCBS.OCBSCATL.domaine AS DOM, 
RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN'
order by OCBS.OCBSCATL.descAn;


--select * from OCBS.OCBSCATL  where element = 'TP_LIEN';
 
 select OCBS.OCBSLTRL.tp_lien as type, RTRIM(OCBS.OCBSLTRL.tp_client1) as type_client_1, RTRIM(OCBS.OCBSLTRL.tp_client2) as type_client_2, 
 RTRIM(OCBS.OCBSLTRL.ind_pct_particip) as pct_participant, OCBS.OCBSLTRL.tp_rel_client as relationtype FROM OCBS.OCBSLTRL
