--Retrieve Phone Type List (for both Client and Business, no data return, this could be used for new phone type definition)

/*					
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_TEL_CLI_C' 
order by OCBS.OCBSCATL.descAn;

*/

select * from OCBS.OCBSCATL  where element = 'TP_LIEN';

select  * from OCBS.OCBSCATL  where element = 'CATEGORY_TELEPHONE';


select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
FROM OCBS.OCBSCATL WHERE OCBS.OCBSCATL.element = 'CATEGORY_TELEPHONE' order by OCBS.OCBSCATL.descAn
 
 select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
 WHERE OCBS.OCBSCATL.element = 'CATEGORY_TELEPHONE' order by OCBS.OCBSCATL.descAn
 
select referenceBPM, refBPM_CategProcess, refBPM_Process, ID_boiteFax, ID_codeForm, ID_groupeLog, groupeTraitement, processDeclenche, nomTache, slaLog 
FROM locale.CL67_configBoiteFormGroup