SELECT *  FROM OCBS.OCBSCATL 
					WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
					AND OCBS.OCBSCATL.domaine = 'PSC';
					
SELECT * FROM OCBS.OCBSLTRL
					WHERE tp_rel_client = 'CE' and tp_lien = 'PSC';
					
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
					WHERE OCBS.OCBSCATL.element = 'TP_REL_CLIENT_DA' 
					AND OCBS.OCBSCATL.domaine = 'BFI';
					
select  * from OCBS.OCBSCATL  
					where element = 'CATEGORY_TELEPHONE';


