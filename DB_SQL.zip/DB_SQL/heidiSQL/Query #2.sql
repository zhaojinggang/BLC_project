select  * from OCBS.OCBSCATL  where element = 'CATEGORY_TELEPHONE';


select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
FROM OCBS.OCBSCATL WHERE OCBS.OCBSCATL.element = 'CATEGORY_TELEPHONE' order by OCBS.OCBSCATL.descAn;


select OCBS.OCBSLTRL.tp_lien as type, RTRIM(OCBS.OCBSLTRL.tp_client1) as type_client_1, RTRIM(OCBS.OCBSLTRL.tp_client2) as type_client_2, 
RTRIM(OCBS.OCBSLTRL.ind_pct_particip) as pct_participant, OCBS.OCBSLTRL.tp_rel_client as relationtype FROM OCBS.OCBSLTRL;

select count(*) FROM OCBS.OCBSLTRL;

				
SELECT *		FROM OCBS.OCBSLTRL
WHERE tp_lien = 'PSC';

select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
			WHERE OCBS.OCBSCATL.element = 'TP_REL_CLIENT_DA' 
			order by OCBS.OCBSCATL.descAn;
			
SELECT * FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_REL_CLIENT_DA' ;
			
--INSERT INTO OCBS.OCBSCATL (element, domaine, descFr, descAn, sys_lastupd_ts, sys_lastupd_usr)
--					VALUES ( 'TP_REL_CLIENT_DA', 'BFI', 'BENEFICIARE FIDUCIE', 'TRUST BENEFICIARY', SYSDATETIME(), 'bpmun1c');
-- ocbsatl_tp_client,


SELECT  referenceBPM,  OCBSCATL_tp_client, OCBSCATL_cd_categ_client, descAn, descFr
from locale.CL04_typeClient;
