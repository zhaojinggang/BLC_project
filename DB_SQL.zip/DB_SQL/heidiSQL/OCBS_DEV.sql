SELECT  * from OCBS.OCBSCATL  where element = 'CATEGORY_TELEPHONE';


select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
FROM OCBS.OCBSCATL WHERE OCBS.OCBSCATL.element = 'CATEGORY_TELEPHONE' order by OCBS.OCBSCATL.descAn

-- select gender on information page
select referenceBPM, RTRIM(descAn) AS DESCR FROM locale.CL19_Sexe order by ordre

-- select Phone Country List, phoneCountryList[] name:CANADA-001, value:CANADA-001
select RTRIM(nom_cd_pays_an+'-'+ind_pays), cd_pays from OCBS.OCBSPAYS WHERE ind_pays IS NOT NULL AND ind_pays <> '' order by nom_cd_pays_an

-- select Marital Status List from Information page
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_ETAT_CIVIL' order by OCBS.OCBSCATL.descAn;

-- select phone cateory (front end) ---> backend (phone type), phoneCategorList: eg: valuel: 4, name BUSINESS
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'CATEGORY_TELEPHONE' order by OCBS.OCBSCATL.descAn;

-- select Relationship Type (English)
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
order by OCBS.OCBSCATL.descAn;

-- select Relationship Type (English)
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
order by OCBS.OCBSCATL.descAn;

SELECT *  FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
AND OCBS.OCBSCATL.domaine = 'PSC'
order by OCBS.OCBSCATL.descAn;

SELECT COUNT(*) FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN';


--INSERT INTO OCBS.OCBSCATL (element, domaine, descFr, descAn, sys_lastupd_ts, sys_lastupd_usr)
--					VALUES ( 'TP_LIEN', 'PSC', 'CONTACT SADC', 'CDIC CONTACT', SYSDATETIME(), 'bpmun1c');
					
COMMIT;
			
-- select Relationship Type (English)
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
order by OCBS.OCBSCATL.descAn;



select COUNT(*) FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN' ;


SELECT * FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
AND OCBS.OCBSCATL.domaine = 'PSC';



-- select product Relationship Type (English)
select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_REL_CLIENT_DA' 
order by OCBS.OCBSCATL.descAn;

select * FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_REL_CLIENT_DA';

select COUNT(*) FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'TP_REL_CLIENT_DA';

--INSERT INTO OCBS.OCBSCATL (element, domaine, descFr, descAn, sys_lastupd_ts, sys_lastupd_usr)
--					VALUES ( 'TP_REL_CLIENT_DA', 'BFI', 'BENEFICIARE FIDUCIE', 'TRUST BENEFICIARY', SYSDATETIME(), 'bpmun1c');
					

-- retreive relation link type list
SELECT OCBS.OCBSLTRL.tp_lien as type, RTRIM(OCBS.OCBSLTRL.tp_client1) as type_client_1, RTRIM(OCBS.OCBSLTRL.tp_client2) as type_client_2, 
RTRIM(OCBS.OCBSLTRL.ind_pct_particip) as pct_participant, OCBS.OCBSLTRL.tp_rel_client as relationtype 
FROM OCBS.OCBSLTRL;

SELECT *
FROM OCBS.OCBSLTRL
WHERE tp_lien = 'LNE';

--INSERT INTO OCBS.OCBSLTRL (tp_rel_client, tp_lien, tp_client1, tp_client2, ind_pct_particip, sys_last_upd_ts, sys_last_upd_usr)
--					VALUES ( 'CE', 'PSC', 'C', 'C', 'N', SYSDATETIME(), 'bpmun1c');

SELECT *
	FROM OCBS.OCBSLTRL
	WHERE 1=1 
	--AND tp_rel_client = 'CI'
	--and tp_lien = 'PSC';

SELECT * FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.domaine IN ('ADT', 'GRP');
	




