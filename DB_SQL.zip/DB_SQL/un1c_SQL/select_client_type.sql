SELECT  referenceBPM,  OCBSCATL_tp_client, OCBSCATL_cd_categ_client, descAn, descFr
from locale.CL04_typeClient;


