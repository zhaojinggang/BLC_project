USE [OCBS_DATA_PREPROD];

EXEC sp_tables @table_type = "'table'";

EXEC sp_help 'OCBS.OCBSCATL';

EXEC sp_columns OCBSCATL;
exec sp_columns OCBSCATL, @column_name = 'domaine';


select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
		 FROM OCBS.OCBSCATL 
		 WHERE OCBS.OCBSCATL.element = 'TP_LIEN'
		 order by OCBS.OCBSCATL.descAn;

--select referenceBPM, RTRIM(descAn) AS DESCR FROM locale.CL19_Sexe order by ordre
-- select * from locale.CL19_Sexe

select * from locale.CL00_parameters;
select * from locale.CL01_autresCritere;
select * from locale.CL02_systOperationnels;
select * from locale.CL03_distributeurs;


select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
 FROM OCBS.OCBSCATL 
 WHERE 1=1
and OCBS.OCBSCATL.element = 'TP_RUE_ABR' and OCBS.OCBSCATL.domaine is not null 
and RTRIM(OCBS.OCBSCATL.domaine) <> '' 
and RTRIM(OCBS.OCBSCATL.domaine) <> 'XX'  
 order by OCBS.OCBSCATL.descAn;
 
 
 -- employment status (select client -->  )
 select OCBS.OCBSCATL.domaine AS DOM, RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
 FROM OCBS.OCBSCATL 
 WHERE OCBS.OCBSCATL.element = 'EMPL_STATUT' 
 order by OCBS.OCBSCATL.descAn;
 
 -- relationship type
 select * 
 FROM OCBS.OCBSCATL 
 WHERE OCBS.OCBSCATL.element = 'TP_LIEN' 
 order by OCBS.OCBSCATL.descAn;
 
 -- select occupation type
select OCBS.OCBSCATL.domaine, RTRIM(OCBS.OCBSCATL.domaine) + ' - ' + RTRIM(OCBS.OCBSCATL.descAn) AS DESCR 
FROM OCBS.OCBSCATL 
WHERE OCBS.OCBSCATL.element = 'CD_OCCUPATION' 
order by OCBS.OCBSCATL.domaine; 


-- select client type
select distinct referenceBPM, RTRIM(CL04_typeClient.descAn), CL04_typeClient.descAn 
from locale.CL04_typeClient
order by CL04_typeClient.descAn 

    