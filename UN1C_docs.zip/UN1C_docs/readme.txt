$HOME

•	https://zone.coll.banquelaurentienne.ca/sites/os/UN1C/SitePages/Accueil.aspx
•	https://zone.coll.banquelaurentienne.ca/sites/os/UN1C/Documentation/Forms/AllItems.aspx?RootFolder=%2Fsites%2Fos%2FUN1C%2FDocumentation%2FDocumentation%2FProcessus%20d%27%C3%A9quipe%2FBPM

Fonctionnels
o	CLIENT
https://zone.coll.banquelaurentienne.ca/qc/collaboration/projetGDC/sunrise/venir/Forms/AllItems.aspx?RootFolder=/qc/collaboration/projetGDC/sunrise/venir/04%20ANALYSE/3%20Versions%20en%20cours/BPM%20-%20Analyses%20fonctionnelles&FolderCTID
 
o	PROJET BERMUDA - CLIENT : https://zone.coll.banquelaurentienne.ca/sites/ProjetsTI/Bermuda/IT/Forms/AllItems.aspx
 
o	PROJET PHOENIX (NEW) : https://banquelaurentienne.sharepoint.com/sites/PWA-Prod/15000E - Phoenix - Améliorations fonctionnelles (Démarrage)/3Livrables
o	PROJET PHOENIX (OLD) :  https://blc.eppm.cgi.com/PWA/15000E%20-%20Phoenix%20-%20Améliorations%20fonctionnelles%20(Démarrage)/3Livrables/Forms/AllItems.aspx?RootFolder=%2FPWA%2F15000E%20%2D%20Phoenix%20%2D%20Am%C3%A9liorations%20fonctionnelles%20%28D%C3%A9marrage%29%2F3Livrables%2FJ3%2D%20LIVRAISON%2FLivraison%202%2FJ3%2E1%2D%20Analyse%20d%C3%A9taill%C3%A9e
 
o	VISA
o	J:\TI_INET\UN1C_BPM\Documentation\Document projet\EPM Visa Integral\


User Guide
https://zone.banquelaurentienne.ca/qc/montravail/biblio/Pages/chapitre.aspx?vc=v13c11

Architecture
Voir document joint au courriel

