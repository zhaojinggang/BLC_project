+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Datapower change:
	
	*) BPM-DEV & BPM-PrePROD (updated history)
	
		- 2021-12-23	update 1_PartyDatamgmt and 2_ClientProfileDataLoc (BLCDomainLibraryFSC.xsd)
		
		- 2021-12-24	update 1_PartyDatamgmt and 2_ClientProfileDataLoc (BLCDomainLibraryFSC.xsd), change phonetype ... from mandatory to optional
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		